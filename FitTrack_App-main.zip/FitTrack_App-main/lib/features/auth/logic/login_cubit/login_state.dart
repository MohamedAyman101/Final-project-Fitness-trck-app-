abstract class LoginState {}

final class LoginInitial extends LoginState {}
