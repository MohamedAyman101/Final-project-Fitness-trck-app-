class ExerciseModel {
  final String name;
  final String description;
  final String image;
  final String video;
  final String time;
  final String Kcal;

  ExerciseModel({required this.name, required this.description, required this.image, required this.video, required this.time, required this.Kcal});
}