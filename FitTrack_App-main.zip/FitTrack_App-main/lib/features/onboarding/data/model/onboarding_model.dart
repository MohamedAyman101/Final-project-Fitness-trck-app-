class OnBoardingModel {
  final String image;

  final String body;

  OnBoardingModel({required this.image, required this.body});
}
