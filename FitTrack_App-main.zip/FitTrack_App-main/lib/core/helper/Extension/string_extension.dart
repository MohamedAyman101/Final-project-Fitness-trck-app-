extension StringExtension on String? {
  bool isNullOrEmpty() => this == null || this!.isEmpty;
}
