class Routes {
  // any one make route add name in this file
  static const String splashScreen = 'splashScreen';
  static const String onBoardingScreen = 'onBoardingScreen';
  static const String appLayout = 'appLayout';
  static const String loginScreen = 'loginScreen';
  static const String registerScreen = 'registerScreen';
  static const String mealDetailScreen = 'mealDetailScreen';
  static const String mealsScreen = 'mealScreen';
  static const String trainingScreen = 'trainingScreen';
}
