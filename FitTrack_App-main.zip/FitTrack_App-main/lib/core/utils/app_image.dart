class AppImage {
  // ading image path in this image
  static const String logo = '';
  static const String food1Image = 'assets/images/food1.png';
}
