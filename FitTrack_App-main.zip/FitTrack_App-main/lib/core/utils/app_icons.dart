class AppIcons {
  // adding path of any svg icon
  static const String homeIcon = '';

  static const String kcalIcon = 'assets/icons/kcal.svg';
  static const String clockIcon = 'assets/icons/clock.svg';
  static const String lineIcon = 'assets/icons/Line.svg';
  static const String arrowBackIcon = 'assets/icons/Back.svg';
  static const String googleIcon = 'assets/icons/google-icon.svg';
  static const String groupIcon = 'assets/icons/group.svg';
  static const String pathIcon = 'assets/icons/path.svg';
  static const String weightIcon = 'assets/icons/weight_lose.svg';
  static const String editIcon = 'assets/icons/edit-btn.svg';
}
