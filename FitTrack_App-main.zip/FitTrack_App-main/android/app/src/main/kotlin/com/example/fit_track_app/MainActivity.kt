package com.example.fit_track_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
